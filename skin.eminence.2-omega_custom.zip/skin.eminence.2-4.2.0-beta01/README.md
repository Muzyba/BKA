# Description
This fork was created to provide compatibility for Eminence with Kodi 21 Omega. I Love Eminence.
I started off with the work found at https://forum.kodi.tv/archive/index.php?thread-375914-2.html and improved on it a little. Credits to the people there.
All changes in this fork will be sent as pull request upstream.


This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
