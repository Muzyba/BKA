# -*- coding: utf-8 -*-
import sys
try:
    sys.path.append(sys.path[0] + '/../script.module.kover/lib')  # minimalizuje ilość błędów w logach
    # 3 poniższe potrzebne do pobierania
    sys.path.append(sys.path[0] + '/../script.module.ptw/lib')
    sys.path.append(sys.path[0] + '/../script.module.pyxbmct/lib')
    # sys.path.append(sys.path[0] + '/modules')  # przeniosłem do resources/lib
    from kover import autoinstall  # noqa: F401
except Exception:
    import traceback
    import xbmc
    xbmc.log(f'\n{traceback.format_exc()}',1)
    pass

import sys, re, os, json
import hashlib
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
import xbmcplugin
import resolveurl as urlresolver
import base64
import requests
from html import unescape

# xbmc.log("START",1)

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
  
if sys.version_info >= (3,0,0):
# for Python 3
    from resources.lib.cmf3 import parseDOM
    import http.cookiejar as cookielib
    from urllib.parse import unquote,parse_qs, quote, urlencode, quote_plus, parse_qsl
    import urllib.parse as urlparse
    xrange = range
    unicode = str
else:
    # for Python 2
    from resources.lib.cmf2 import parseDOM

    import cookielib
    from urllib import unquote, quote, urlencode, quote_plus
    import urlparse
    from urlparse import parse_qs, parse_qsl
  

# Disable InsecureRequestWarning
requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)
  
  
cache = StorageServer.StorageServer("filmancc")  # dane w pliku %appdata%/Kodi/cachecommoncache.db

window = xbmcgui.Window(10000)

base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')
addonId         = my_addon.getAddonInfo('id')
FanFilmAddonId  = my_addon.getSetting('FanFilmAddonId') or "plugin.video.fanfilm"  # potrzebne, gdy chcemy przechodzić do FanFilm
PATH            = my_addon.getAddonInfo('path')
try:
    DATAPATH = xbmcvfs.translatePath(my_addon.getAddonInfo('profile'))
except:
    DATAPATH = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES = PATH+'/resources/'
FANART = RESOURCES+'fanart.png'
sys.path.append( os.path.join( RESOURCES, "lib" ) )



if not my_addon.getSetting('download.path'):
    my_addon.setSetting('download.path', 'filmancc')  # na sztywno (na testy)
try:
    import ptw.libraries.downloader as dw  # jako test
    download_available = True
except:
    download_available = False
    xbmc.log('pobieranie nie będzie możliwe (brak modułu PTW)',1)



if  my_addon.getSetting("cookies_from_FF_plugin") == "true":

    FF_addon = xbmcaddon.Addon(FanFilmAddonId)

    if my_addon.getSetting("FF_version") == "0":  # tele
        UA = FF_addon.getSetting('filman_web.USER_AGENT')
        COOKIES = FF_addon.getSetting('filman_web.cookies')
        cf = FF_addon.getSetting('filman_web.cookies.cf')
    else:  # Beta
        UA = FF_addon.getSetting('filman.user_agent')
        COOKIES = FF_addon.getSetting('filman.cookies')
        cf = FF_addon.getSetting('filman.cookies_cf')

    if my_addon.getSetting("UA") != UA:
        my_addon.setSetting('UA', UA)
    if my_addon.getSetting("COOKIES") != COOKIES:
        my_addon.setSetting('COOKIES', COOKIES)
    if my_addon.getSetting("COOKIES.cf") != cf:
        my_addon.setSetting('COOKIES.cf', cf)



if not (UA := my_addon.getSetting("UA").strip(' "\'')):
    UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0'


COOKIES = my_addon.getSetting("COOKIES").strip(' "\'')
# COOKIES = "bbb"  # przykład
if COOKIES and "=" not in COOKIES:
    COOKIES = "BKD_REMEMBER=" + COOKIES
else:
    COOKIES = re.sub('PHPSESSID=[^;]*;?', '', COOKIES).strip(' ;')
# ciasteczko od Cloudflare
cf = my_addon.getSetting("COOKIES.cf").strip(' "\'')
# cf = "ccc"  # przykład
COOKIES += "; cf_clearance=" + cf if cf else ""
other_sess_mode = my_addon.getSetting("other_sess_mode") == "true"


fname = args.get('foldername',[''])[0]

mainurl = 'https://filman.cc/'
mybtn_user = ''
TIMEOUT = 10

BASEURL='https://filman.cc/'

COOKIEFILE = os.path.join(DATAPATH,'filmancookie')

sess=requests.Session()
sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)

sess2=requests.Session()



def rozbij_tytuly(title, ret_dict=False):
    titles = title.split(" / ")
    title = titles[0]
    originaltitle = titles[-1]
    englishtitle = titles[1] if len(titles)>1 else ""
    q = englishtitle or originaltitle
    # q = originaltitle  # dla chińskich może być problem
    if ret_dict:
        q = {"title": title, "originaltitle": originaltitle, "englishtitle": englishtitle}
    # xbmc.log(f'[rozbij_tytuly] {q=}',1)
    return q



def zapytaj_co_wyslac_do_FF(title, year=''):
    titles = title.split(" / ")
    if len(titles) > 1:
        selected = xbmcgui.Dialog().select("Który tytuł przesłać do FanFilm?", titles, preselect=len(titles)-1)
    else:
        selected = 0
    if selected > -1:
        stitle = titles[selected]
    else:
        stitle = ""
    if stitle and year:
        while True:
            s = xbmcgui.Dialog().input("Rok premiery", year, type=xbmcgui.INPUT_NUMERIC)
            if not s or re.match(r"^(19|20)[\d]{2,2}$", s):
                break
            if not xbmcgui.Dialog().yesno('Niepoprawna wartość', (f"Wpisana wartość [B]{s}[/B] jest nieprawidłowa. \nCzy chcesz poprawić? \n[COLOR gray]dozwolony zakres to [1900-2099][/COLOR]")):
                s = ''
                break
        year = s
        if year:
            stitle += f" ({year})"
        else:
            stitle = ""  # rezygnacja użytkownika
    # xbmc.log(f'[zapytaj_co_wyslac_do_FF] {stitle=}',1)
    return stitle



def zapytaj_o_numer_podstrony(page, total_pages):
    while True:
        # s = xbmcgui.Dialog().input(f"wpisz numer strony\n(maks. {total_pages})", str(page), type=xbmcgui.INPUT_NUMERIC)
        s = xbmcgui.Dialog().input(f"wpisz numer strony\n(maks. {total_pages})", type=xbmcgui.INPUT_NUMERIC)
        if not s or 0 <= int(s) <= int(total_pages):
            break
        if not xbmcgui.Dialog().yesno('Niepoprawna wartość', (f"Wpisana wartość [B]{s}[/B] jest nieprawidłowa. \nCzy chcesz poprawić? \n[COLOR gray]dozwolony zakres to 1-{total_pages}[/COLOR]")):
            s = ''
            break
    return s



def addLinkItem(name, url, mode, page=1, iconimage='DefaultFolder.png', infoLabels=False, contextO='', IsPlayable=False, fanart=FANART, itemcount=1):

    u = build_url({'mode': mode, 'foldername': name, 'ex_link': url, 'page': page, 'token': mybtn_user})

    if not infoLabels:  # dla pozycji menu
        # xbmc.log(f'[addLinkItem] {infoLabels=}',1)
        infoLabels = {}
    if 'true' in my_addon.getSetting('addYear'):
        if infoLabels.get('year'):
            # name = f'{infoLabels["title"]} [LIGHT]({infoLabels["year"]})[/LIGHT]'
            name += f' [LIGHT]({infoLabels["year"]})[/LIGHT]'
            # infoLabels["title"] = f'{infoLabels["title"]} [LIGHT]({infoLabels["year"]})[/LIGHT]'  # tylko to nie jest do końca poprawne, bo title przykrywa label, gdy źle sortowanie jest określone
            # infoLabels.pop('year', None)  # fix dla skórek, która wyświetla rok po tytule (aby nie było zdublowania roku)
    # xbmc.log(f'[addLinkItem] {infoLabels=}',1)

    liz = xbmcgui.ListItem(name)  # label

    art_keys=['icon', 'thumb', 'poster', 'banner', 'landscape']
    if infoLabels and fanart is not None:
        art_keys.append('fanart')
        pass
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    # xbmc.log(f'[addLinkItem] {art=}',1)
    liz.setArt(art)
    
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')
    
    isp = []
    if isinstance(contextO, list) and contextO and isinstance(contextO[0], tuple):
        isp = contextO
    if 'Komentarze' in contextO:
        isp.append(('[B]Komentarze[/B]', 'RunPlugin(plugin://%s?mode=Komentarze&ex_link=%s)' % (addonId, url)))
        pass
    if 'FF' in contextO and FanFilmAddonId:
        if 'true' in my_addon.getSetting('selectTitleToFanFilm'):
            qtitle = infoLabels.get("tvshowtitle") or infoLabels["title"] or ''
            qyear = infoLabels.get('tvshowyear') or infoLabels.get('year') or ''
            if infoLabels.get("tvshowtitle"):
                isp.append(('Wyszukaj serial w [B]FanFilm[/B]', 'RunPlugin(plugin://%s?mode=selectTitleToFanFilm&mtype=tv&title=%s&year=%s)' % (addonId, quote_plus(qtitle), qyear)))
            else:
                isp.append(('Wyszukaj w [B]FanFilm[/B]', 'RunPlugin(plugin://%s?mode=selectTitleToFanFilm&mtype=movie&title=%s&year=%s)' % (addonId, quote_plus(qtitle), qyear)))
        else:
            q = rozbij_tytuly(infoLabels.get("tvshowtitle") or infoLabels["title"])
            # dodawanie roku może nie być dobrym pomysłem, bo bywają rozbieżności
            if infoLabels.get('tvshowyear'):
                q += f' ({infoLabels["tvshowyear"]})'
            elif infoLabels.get('year'):
                q += f' ({infoLabels["year"]})'
            if infoLabels.get("tvshowtitle"):
                isp.append(('Wyszukaj serial w [B]FanFilm[/B]', 'Container.Update(plugin://%s?action=tvSearchterm&name=%s)' % (FanFilmAddonId, quote_plus(q))))
                # xbmc.log(f'[addLinkItem] serial {q=}',1)
            else:
                # xbmc.log(f'[addLinkItem] film {q=}',1)
                isp.append(('Wyszukaj w [B]FanFilm[/B]', 'Container.Update(plugin://%s?action=movieSearchterm&name=%s)' % (FanFilmAddonId, quote_plus(q))))
    if download_available and 'DOWNLOAD' in contextO:
        content = quote_plus(json.dumps(infoLabels))
        isp.append(('[LIGHT]Pobierz[/LIGHT]', 'RunPlugin(plugin://%s?mode=DOWNLOAD&ex_link=%s)' % (addonId, content)))
        pass

    if isp:
        liz.addContextMenuItems(isp, replaceItems=False)

    if infoLabels:
        infoLabels.pop('href', None)
        infoLabels.pop('img', None)
        infoLabels.pop("", None)
        infoLabels.pop("ep_title", None)
        infoLabels.pop("tvshowyear", None)
        liz.setInfo(type="Video", infoLabels=infoLabels)  # deprecated
        # InfoTagVideo
        # vtag = liz.getVideoInfoTag()
        # vtag.setTitle(infoLabels["title"])
        # vtag.setPlot(infoLabels["plot"])
        # vtag.setYear(infoLabels["year"])
        # ...

    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=False, totalItems=itemcount)

    # czemu taka dziwna konstrukcja z tym sortowaniem?  https://github.com/retrospect-addon/kodi.emulator.ascii/blob/master/xbmcplugin.py
    if False:
        # alternatywa
        labelMask = "%L"
        label2Mask = "%R, %Y, %P"
        if 'true' in my_addon.getSetting('addYear'):
            labelMask = "%L, %Y"
            label2Mask = "%R, %P"
        # xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, labelMask=labelMask, label2Mask=label2Mask)  # to powinno być dopiero gdy zamykamy folder
        pass
    # return ok



def addDir(name, ex_link=None, page=1, mode='folder', iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART, contextmenu=None):

    url = build_url({'mode': mode, 'foldername': name, 'ex_link': ex_link, 'page': page, 'iconImage': iconImage, 'token': mybtn_user})
    # xbmc.log(f'{url=}',1)

    if not infoLabels:
        # xbmc.log(f'[addDir] {infoLabels=}',1)
        infoLabels = {}
    if 'true' in my_addon.getSetting('addYear'):
        if infoLabels.get('year'):
            # name = f'{infoLabels["title"]} [LIGHT][I]({infoLabels["year"]})[/I][/LIGHT]'
            name += f' [LIGHT][I]({infoLabels["year"]})[/I][/LIGHT]'
            # infoLabels["title"] = f'{infoLabels["title"]} [LIGHT][I]({infoLabels["year"]})[/I][/LIGHT]'  # uwaga: title przykrywa label
            # infoLabels.pop('year', None)  # fix dla skórek, która wyświetla rok po tytule (aby nie było zdublowania roku)
    infoLabels.pop('href', None)
    infoLabels.pop('img', None)
    # xbmc.log(f'[addDir] {name=}  {infoLabels=}',1)

    li = xbmcgui.ListItem(name)

    if infoLabels:
        infoLabels.pop("", None)
        li.setInfo(type="video", infoLabels=infoLabels)
    
    art_keys=['icon', 'thumb', 'poster', 'banner', 'landscape']
    if infoLabels and fanart is not None:
        art_keys.append('fanart')
        pass
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    li.setArt(art)
    
    if contextmenu:
        isp = contextmenu
        li.addContextMenuItems(isp, replaceItems=True)
    
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)



def encoded_dict(in_dict):
    out_dict = {}
    try:
        # Python 2
        iter_dict = in_dict.iteritems()
    except AttributeError:
        # Python 3
        iter_dict = in_dict.items()
    out_dict = {}
    for k, v in iter_dict:
   # for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict



def build_url(query):
    return base_url + '?' + urlencode(encoded_dict(query))



def listTv(ex_link):
    mlinks = getTvs(ex_link)
    items = len(mlinks)
    for f in mlinks:
        addDir(name=f.get('title'), ex_link=f.get('href'), mode='getTvLinks', iconImage=f.get('img'), infoLabels={'plot':f.get('title')})



def listMovies(ex_link, page, last_page=0):
    # xbmc.log(f'[listMovies] {ex_link=} {page=}',1)

    page = int(page) if page else 1

    if last_page:
        new_page = zapytaj_o_numer_podstrony(page, last_page)
        # xbmc.log(f'{new_page=}  {base_url=}',1)
        if new_page == '0':
            xbmc.executebuiltin('Container.Update(%s, replace)' % base_url)
            return
        if new_page:
            page = int(new_page)
        else:
            page = page - 1 if page > 1 else 1

    group = ''

    if '|'in ex_link:
        ex_link, group = ex_link.split('|')

    # xbmc.log(f'[listMovies] {ex_link=} {page=}',1)
    mlinks, mparams = getMovies(ex_link, page, group)

    if mparams[0]:
        # addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__M', page=mparams[0], IsPlayable=False)
        pass
    
    items = len(mlinks)
    
    for f in mlinks:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD', 'Komentarze', 'FF'], IsPlayable=True, itemcount=items)
    
    if mparams[1]:
        # addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__M', page=mparams[1], IsPlayable=False)
        cm = []
        if mparams[2]:
            cm.append(('Wybierz stronę', 'Container.Update(plugin://%s?mode=%s&ex_link=%s&page=%s&last_page=%s)' % (addonId, 'ListMovies', quote(ex_link), mparams[1], mparams[2]) ))
            addDir(name=f'[I][LIGHT]następna strona[/LIGHT] ({mparams[1]} z {mparams[2]})[/I]', ex_link=ex_link, mode='ListMovies', page=mparams[1], contextmenu=cm)
        else:
            addDir(name=f'[I][LIGHT]następna strona[/LIGHT] ({mparams[1]})[/I]', ex_link=ex_link, mode='ListMovies', page=mparams[1])



def listSeries(ex_link, page, last_page=0):
    # xbmc.log(f'[listSeries] {ex_link=} {page=}',1)
    page = int(page) if page else 1
    if last_page:
        new_page = zapytaj_o_numer_podstrony(page, last_page)
        if new_page == '0':
            xbmc.executebuiltin('Container.Update(%s, replace)' % base_url)
            return
        if new_page:
            page = int(new_page)
        else:
            page = page - 1 if page > 1 else 1


    if '|'in ex_link:
        ex_link, group = ex_link.split('|')
    else:
        group = ''

    '''
    if group:
        mlinks, mparams = getSeries(ex_link,int(page),group)
    else:
        mlinks, mparams = getSeries(ex_link)
    '''
    mlinks, mparams = getSeries(ex_link, int(page), group)
    
    my_mode = 'getEpisodes'
    if 'true' in my_addon.getSetting('groupEpisodes'):
        my_mode = 'getSeasons'
    # xbmc.log(f'[listSeries] {my_mode=}',1)

    if mparams[0]:
        # addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__S', page=mparams[0], IsPlayable=False)
        pass

    items = len(mlinks)
    # xbmc.log(f'[listSeries] {items=}',1)

    for f in mlinks:
        isp = []
        isp.append(('[B]Komentarze[/B]', 'RunPlugin(plugin://%s?mode=Komentarze&ex_link=%s)' % (addonId, f.get('href'))))

        if FanFilmAddonId:
            if 'true' in my_addon.getSetting('selectTitleToFanFilm'):
                isp.append(('Wyszukaj w [B]FanFilm[/B]', 'RunPlugin(plugin://%s?mode=selectTitleToFanFilm&mtype=tv&title=%s&year=%s)' % (addonId, quote_plus(f["title"]), f.get('year'))))
            else:
                q = rozbij_tytuly(f["title"])
                if f.get('year'):  # tu nie będzie roku, bo strona nie podaje go na liście seriali
                    q += f' ({f["year"]})'
                # xbmc.log(f'[listSeries] {q=}',1)
                isp.append(('Wyszukaj w [B]FanFilm[/B]', 'Container.Update(plugin://%s?action=tvSearchterm&name=%s)' % (FanFilmAddonId, quote_plus(q))))

        # addDir(name=f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'), contextmenu=isp)#, infoLabels=f)
        addDir(name=f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'), contextmenu=isp, infoLabels=f)

    if mparams[1]:
        # addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__S', page=mparams[1], IsPlayable=False)
        if mparams[2]:
            cm = []
            cm.append(('Wybierz stronę', 'Container.Update(plugin://%s?mode=%s&ex_link=%s&page=%s&last_page=%s)' % (addonId, 'ListSeriale', quote(ex_link), mparams[1], mparams[2]) ))
            addDir(name=f'[I][LIGHT]następna strona[/LIGHT] ({mparams[1]} z {mparams[2]})[/I]', ex_link=ex_link, mode='ListSeriale', page=mparams[1], contextmenu=cm)
        else:
            addDir(name=f'[I][LIGHT]następna strona[/LIGHT] ({mparams[1]})[/I]', ex_link=ex_link, mode='ListSeriale', page=mparams[1])



def getSeasons(ex_link):
    # xbmc.log(f'[getSeasons] {ex_link=}',1)

    if 'true' not in my_addon.getSetting('groupEpisodes'):
        return getEpisodes(ex_link)

    episodes = scanEpisodes(ex_link)
    if episodes:
        imag = episodes[0].get('img')#
        seasons = splitToSeasons(episodes)
        # xbmc.log(f'{seasons=}',1)
        if my_addon.getSetting('descSortEpisodes') != 'true':
            reverse_order = False  # (ascending order)
        else:
            reverse_order = True  # (descending order)
        cache.delete('season_%')
        for i in sorted(seasons.keys(), reverse=reverse_order):
            key = f'season_{seasons[i][0]["season"]}|' + hashlib.md5(ex_link.encode()).hexdigest()
            cache.set( key, str(seasons[i]) )
            # xbmc.log(f'[getSeasons] {seasons[i]=}',1)
            # addDir(name=i, ex_link=quote(str(seasons[i])), iconImage=imag, mode='getEpisodes2')
            addDir(name=i, ex_link=f'season_{seasons[i][0]["season"]}|{ex_link}', iconImage=imag, mode='getEpisodes2')
    
        xbmcplugin.setContent(addon_handle, 'seasons')
        xbmcplugin.endOfDirectory(addon_handle,True)        
    else:
        sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]', 'Brak odcinków')



def getEpisodes(ex_link):
    # xbmc.log(f'[getEpisodes] {ex_link=}',1)

    if 'true' in my_addon.getSetting('groupEpisodes'):
        return getSeasons(ex_link)

    episodes = scanEpisodes(ex_link)
    # xbmc.log(f'{episodes=}',1)
    if episodes:
        if my_addon.getSetting('descSortEpisodes') != 'true':
            reverse_order = False  # (ascending order)
        else:
            reverse_order = True  # (descending order)
        # for f in episodes:  # kolejność jak na stronie
        for f in sorted(episodes, key=lambda x: (x['season'], x['episode']), reverse=reverse_order):
            # xbmc.log(f'[getEpisodes] {f=}',1)
            addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD', 'Komentarze', 'FF'], IsPlayable=True)

        xbmcplugin.setContent(addon_handle, 'episodes')
        xbmcplugin.endOfDirectory(addon_handle,True)
    else:
        sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]', 'Brak odcinków')



def getEpisodes2(ex_link):
    # xbmc.log(f'[getEpisodes2] {ex_link=}',1)
    season, ex_link = ex_link.split("|", 1)
    key = season + '|' + hashlib.md5(ex_link.encode()).hexdigest()
    episodes = []
    # episodes = eval(unquote(ex_link))
    episodes = cache.get(key)
    episodes = eval(episodes) if episodes else []
    # xbmc.log(f'{len(episodes)=}',1)

    if not episodes:
        episodes = scanEpisodes(ex_link)
        season = int(season.replace('season_', ''))
        episodes = [i for i in episodes if i["season"] == season]
        cache.set( key, str(episodes) )

    # for f in episodes:
    if my_addon.getSetting('descSortEpisodes') != 'true':
        reverse_order = False  # (ascending order)
    else:
        reverse_order = True  # (descending order)

    for f in sorted(episodes, key=lambda x: x['episode'], reverse=reverse_order):
        # xbmc.log(f'[getEpisodes2] {f=}',1)
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD', 'Komentarze', 'FF'], IsPlayable=True, fanart=f.get('img'))

    xbmcplugin.setContent(addon_handle, 'episodes')
    xbmcplugin.endOfDirectory(addon_handle,True)



def listFS(ex_link):
    # xbmc.log(f'[listFS] {ex_link=}',1)
    mlinks, slinks = search(ex_link)

    for f in mlinks:  # filmy
        addLinkItem(name=''+f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, contextO=['DOWNLOAD', 'Komentarze', 'FF'], IsPlayable=True, itemcount=len(mlinks))

    my_mode = 'getEpisodes'
    if 'true' in my_addon.getSetting('groupEpisodes'):
        my_mode = 'getSeasons'
    # xbmc.log(f'[listFS] {my_mode=}',1)
    
    for f in slinks:  # seriale
        isp = []
        isp.append(('[B]Komentarze[/B]', 'RunPlugin(plugin://%s?mode=Komentarze&ex_link=%s)' % (addonId, f.get('href'))))

        if FanFilmAddonId:
            if 'true' in my_addon.getSetting('selectTitleToFanFilm'):
                isp.append(('Wyszukaj w [B]FanFilm[/B]', 'RunPlugin(plugin://%s?mode=selectTitleToFanFilm&mtype=tv&title=%s&year=%s)' % (addonId, quote_plus(f["title"]), f.get('year'))))
            else:
                q = rozbij_tytuly(f["title"])
                if f.get('year'):
                    q += f' ({f["year"]})'
                # xbmc.log(f'[listFS] {q=}',1)
                isp.append(('Wyszukaj w [B]FanFilm[/B]', 'Container.Update(plugin://%s?action=tvSearchterm&name=%s)' % (FanFilmAddonId, quote_plus(q))))

        # addDir(name='[LIGHT]serial[/LIGHT] '+f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'), infoLabels=f, contextmenu=isp)
        addDir(name='[LIGHT][[/LIGHT]'+f.get('title')+'[LIGHT]][/LIGHT]', ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'), infoLabels=f, contextmenu=isp)

    # xbmcplugin.setContent(addon_handle, 'files')
    # xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.setContent(addon_handle, 'movies')

    xbmcplugin.endOfDirectory(addon_handle,True)


    
def getTvLinks(ex_link,rys):
    mlinks = getTvLink(ex_link,rys)
    items = len(mlinks)
    for f in mlinks:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='playTv', iconimage=rys, infoLabels={'plot':f.get('title')}, contextO=['DOWNLOAD'], IsPlayable=True, itemcount=items)
    

    
def PlayTv(ex_link):
    stream_url = ex_link
    if stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))        



def getLinks(ex_link, get_download=False, name='', image='', meta_data=None):
    # xbmc.log(f'[getLinks] {ex_link=} {name=}',1)

    streams, meta = getVideos(ex_link, meta_data)

    # xbmc.log(f'[getLinks] {meta=} \n  {streams=}',1)

    stream_url = ''
    if len(streams) > 0:
    
        t = [x.get('label') for x in streams]  # labele
        u = [x.get('url')   for x in streams]
        # h = [x.get('host')  for x in streams]

        al = "Z jakiego źródla pobieramy?"  if get_download  else "Host  |  Dodane  |  Wersja  | Jakość"

        if "zaskocz-mnie" in ex_link:
            oceny = f'[LIGHT][I]śr. ocen: {meta.get("rating")}  ({meta.get("votes")} głosujących)[/I][/LIGHT]' + "\n\n"
            xbmcgui.Dialog().ok( f'{meta.get("title")}  ({meta.get("year")}) ', oceny + meta.get("plot") )
            xbmc.sleep(200)
            al = f'{meta.get("title")}  ({meta.get("year")}) '

        selected = -1
        def wybieranie_zrodla(preselect=-1):
            nonlocal selected
            stream_url = ''
            selected = xbmcgui.Dialog().select(al, t, preselect=preselect)
            if selected > -1:
                link = u[selected]
                link = parseVideoLink(link, [selected])
                if not stream_url:
                    if '.mp4' in link:  # może to wskazówka do linku, który można pobierać ?
                        stream_url = link + '|User-Agent='+quote(UA)
                    else:
                        try:
                            stream_url = urlresolver.resolve(link)
                        except Exception as e:
                            stream_url = ''
                            sel = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]', 'Może inny link będzie działał?' + '\n\n Resolveurl ERROR: [%s]'%str(e))
                            stream_url = wybieranie_zrodla(preselect=selected)
            else:
                pass    
            return stream_url

        stream_url = wybieranie_zrodla()   
        # xbmc.log(f'[getLinks] {selected=}',1)        

        if stream_url:
            if get_download:
                downloadPath = my_addon.getSetting('download.path')
                if downloadPath and downloadPath != '':
                    # import resources.lib.downloader as dw
                    # from ptw.libraries import downloader
                    import ptw.libraries.downloader as dw
                    try:
                        # xbmc.log(f'[getLinks] {meta=}',1)
                        # xbmc.log(f'[getLinks] {name=}',1)
                        if meta.get("ep_title"):
                            title = meta.get("title").split(" / ")[0]
                            name = f'{title} ({meta.get("year")}) {meta.get("ep_title")}'
                            # xbmc.log(f'[getLinks] {name=}',1)
                            name = name.replace("()", "").replace("(0)", "").replace("  ", " ")
                            # xbmc.log(f'[getLinks] {name=}',1)
                            name = re.sub(r"\[(.+?)\]", r"\1", name, 1)
                            name = re.sub(r' ?[Oo]dcinek \d+$', '', name)
                            # xbmc.log(f'[getLinks] {name=}',1)
                            season_name = "Sezon"
                        else:
                            season_name = ""
                        if meta.get("year") and meta.get("year") not in name:
                            name += f' ({meta.get("year")})'
                        name = downloadPath+'%2F'+name
                        # downloadPath = ""
                        # dw.download(name, image, stream_url, downloadPath)
                        download_ok = dw.download(name, image, stream_url)
                        xbmc.log(f'[getLinks] {download_ok=}',1)
                        if download_ok is False:
                            xbmc.log(f'[getLinks] ponowne wyświetlenie zapytania o źródło pobierania',1)
                            while download_ok is False and (stream_url := wybieranie_zrodla(selected)):
                                download_ok = dw.download(name, image, stream_url, season_name=season_name)
                                xbmc.log(f'[getLinks] {download_ok=}',1)
                                if download_ok is False:
                                    xbmc.log(f'[getLinks] ponowne wyświetlenie zapytania o źródło pobierania',1)
                                    pass
                            xbmc.log(f'[getLinks] opuszczenie procedury ponownego pytania o źródła pobierania',1)
                            pass
                    except Exception:
                        import traceback
                        xbmc.log(f'\n{traceback.format_exc()}',1)
                        xbmc.executebuiltin( "XBMC.Notification(%s,%s,%i,%s)" % ( '[COLOR red] Bląd pobierania [/COLOR]', name, 5000, image))
                else:
                    xbmcgui.Dialog().ok("FilmanCC", "Ustaw docelowy folder!")
                    xbmc.executebuiltin("Addon.OpenSettings(%s)" % addonId)
                return
            liz = xbmcgui.ListItem(path=stream_url)
            # meta.update({"plot": "[filmancc]"})
            if meta.get("ep_title"):
                # meta.update({"title": "[LIGHT]" + meta.get("title") + "[/LIGHT]\n" + meta.get("ep_title")})
                meta.update({ "title": meta.get("ep_title") + "\n" + "[LIGHT]" + meta.get("title") + "[/LIGHT]" })
            meta.pop("ep_title", None)
            liz.setInfo(type="Video", infoLabels=meta)
            # xbmc.log(f'[getLinks] {meta=}',1)
            xbmcplugin.setResolvedUrl(addon_handle, True, liz)
        else:
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
    else:
        if "zaskocz-mnie" in ex_link:
            # xbmcgui.Dialog().notification('[COLOR red][B]Informacja[/B][/COLOR]', 'Wylosowany materiał nie posiada żadnych linków, \nalbo link dostępny jest tylko dla premium. Spróbuj jeszcze raz.', xbmcgui.NOTIFICATION_INFO, 5000)
            xbmcgui.Dialog().ok('Spróbuj jeszcze raz', 'Wylosowany materiał nie posiada żadnych linków, \nalbo link dostępny jest tylko dla premium.')
        else:
            xbmcgui.Dialog().notification('[COLOR red][B]Informacja[/B][/COLOR]', 'Ten materiał nie posiada żadnych linków, \n albo link dostępny jest tylko dla premium.', xbmcgui.NOTIFICATION_INFO, 5000)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))



def getHistory():
    return cache.get('history').split(';')



def setHistory(entry):
    history = getHistory()
    if history == ['']:
        history = []
    history.insert(0, entry)
    cache.set('history', ';'.join(history[:50]))



def remCache(entry):
    history = getHistory()
    # xbmc.log(f'{entry=}  {history=}',1)
    if history:
        history = [h for h in history if h != entry]
        cache.set('history', ';'.join(history[:50]))
    else:
        pass
        # delHistory()



def delHistory():
    cache.delete('history')



def login(refresh=''):
    # xbmc.log("[login] start",1)
    dataPath = os.path.dirname(COOKIEFILE)
    
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)

    u = my_addon.getSetting('user')
    p = my_addon.getSetting('pass')
    l = my_addon.getSetting('login')  # czy logować w serwisie

    logged = False

    # if u and p and l == 'true':
    if l == 'true':
        logged, dane = getLogin(u, p, refresh)
        if logged:
            if logged is not True:
                u = logged
            contextmenu = ''
            contextmenu = [("Odśwież", 'Container.Update(plugin://%s?refresh=1)' % addonId )]
            addLinkItem('#  [B]Zalogowany[/B] [LIGHT] jako[/LIGHT] [B]%s[/B]  [I]%s [/I]' % (u, dane), '', mode=' ', iconimage='DefaultUser.png', IsPlayable=False, contextO=contextmenu)
        else:
            xbmcgui.Dialog().notification('[COLOR red][B]Błąd logowania[/B][/COLOR]', '', xbmcgui.NOTIFICATION_INFO, 5000)
            sess.cookies.clear()
            sess.cookies.save(COOKIEFILE, ignore_discard = True)    
            addLinkItem('[B]Zaloguj[/B]', '', mode='Opcje', iconimage='DefaultUser.png', IsPlayable=False, infoLabels={'plot':'[B]Zaloguj[/B]'})
    else:
        global mybtn_user
        sess.cookies.clear()
        sess.headers.update({
                'Host': 'filman.cc',
                'User-Agent': UA,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                'Referer': 'http://filman.cc/logowanie',
                'Upgrade-Insecure-Requests': '1',
                })
        if other_sess_mode:
            sess.headers.update({'Cookie': COOKIES,})
        url = 'https://filman.cc/logowanie'
        # xbmc.log("[login] 2",1)
        cont = sess.get(url)
        # xbmc.log("[login] 3",1)
        aa = sess.cookies
        my_cookies = requests.utils.dict_from_cookiejar(aa)
        found = ['%s=%s' % (name, value) for (name, value) in my_cookies.items()]
        mybtn_user = ';'.join(found)
        sess.cookies.save(COOKIEFILE, ignore_discard=True)        
        addLinkItem('[B]Zaloguj[/B]', '', mode='Opcje', iconimage='', IsPlayable=False)
    # xbmc.log("[login] koniec",1)

        
#from urlparse import urlparse
#from urlparse import urlsplit



def getLogin(u='', p='', refresh=""):
    # xbmc.log("[getLogin] start",1)
    try:
        import kurw
        kurw.abc()
    except:
        pass

    # fkukz = my_addon.getSetting('fjkukz')  # chyba nie używane już
    # url ='https://filman.cc/logowanie'

    try:
        sess.cookies.clear()
        sess.headers = {
            'Host': 'filman.cc',
            'User-Agent': UA,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
            'dnt': '1',
            'upgrade-insecure-requests': '1',
            'te': 'trailers',
        }
        if other_sess_mode:
            sess.headers.update({'Cookie': COOKIES,})

        # xbmc.log("[getLogin] 2",1)
        # response = sess.get('https://filman.cc/', verify=False)
        response = sess.get('https://filman.cc/kontakt', verify=False)
        # xbmc.log("[getLogin] 3",1)

        if not response:
            # xbmc.log(f'{response=}',1)
            xbmcgui.Dialog().notification('[COLOR red][B]Błąd serwera[/B][/COLOR]: '+str(response.status_code), str(response.reason), xbmcgui.NOTIFICATION_ERROR, 5000)
            xbmc.sleep(4000)
            # raise Exception()
            response.raise_for_status()

        # xbmc.sleep(100)
        # xbmc.log("[getLogin] 4",1)
        # response = sess.get('https://filman.cc/online', verify=False)
        # response = sess.get('https://filman.cc/pomoc', verify=False)
        # response = sess.get('https://filman.cc/logowanie', verify=False)
        # xbmc.log("[getLogin] 5",1)
        if response.text.find('Wyloguj') < 1:
            xbmc.log('trzeba zalogować',1)
            my_addon.setSetting('zalog', 'false')
            if not u or not p:
                xbmc.log(f'brak danych do zalogowania (loginu i hasła)',1)
            data={
                "login": u,
                "password": p,
                "remember": 'on',
                "submit": ''}
            xbmc.sleep(1000)
            response = sess.post('https://filman.cc/logowanie', data=data, verify=False)
        else:
            # xbmc.log('nie trzeba logować',1)
            my_addon.setSetting('zalog', 'true')
            pass

        ab = sess.cookies
        ad = response.cookies
        content = response.text
        
        mybtn_user = ''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
        # xbmc.log(f'{ab=} {ad=} \n{mybtn_user=}',1)        
    except Exception as e:
        content = ''
        if str(e):
            xbmc.log(f'{e}',1)

    dane = ''
    if content.find('Wyloguj') > 0:
        out = True
        try:
            user = parseDOM(content, "a", attrs={"id": "dropdown"})[0]
            user = re.sub("<[^>]+>", "", user).strip()
            user = user.replace("Zalogowany jako:", "")
            out = user if user else out
        except:
            pass
        sess.cookies.save(COOKIEFILE, ignore_discard = True)
        # dane = '[COLOR yellowgreen] darmowe[/COLOR]'
        my_addon.setSetting('zalog', 'true')
        if out != window.getProperty(addonId+'.user_name') or refresh:
            try:
                xbmc.sleep(200)
                # xbmc.log("[getLogin] 6",1)
                content = sess.get('http://filman.cc/premium', cookies=sess.cookies).text
                # xbmc.log("[getLogin] 7",1)
                danex = re.findall(' aktywne konto premium.+?<strong>(.+?)</strong>(.+?)<', content, re.DOTALL)
                if danex:
                    my_addon.setSetting('prem', 'true')
                    dane = '[COLOR orangered] premium do %s %s[/COLOR]'%(danex[0][0], danex[0][1])
                    sess.cookies.save(COOKIEFILE, ignore_discard = True)
                else:
                    my_addon.setSetting('prem', 'false')
                    dane = ''
            except Exception as e:
                my_addon.setSetting('prem', 'false')
                dane = ''
                if str(e):
                    xbmc.log(f'{e}',1)
                    pass
        else:
            # dane = my_addon.getSetting('dane_prem')
            dane = window.getProperty(addonId+'.dane_prem')
    else:
        out = False
        dane = ''
        my_addon.setSetting('zalog', 'false')
        xbmc.log('nie zalogowano :(',1)
        # xbmc.log(f'{content=}',0)

    # xbmc.log(f'{str(out)=}  {dane=}',1)

    # my_addon.setSetting('user_name', str(out))
    # my_addon.setSetting('dane_prem', dane)
    # a może to do pamięci dawać? wówczas po restarcie Kodi wyczyści się
    window.setProperty(addonId+'.user_name', str(out))
    window.setProperty(addonId+'.dane_prem', dane)

    # xbmc.log("[getLogin] koniec",1)
    return out, dane



def getUrlReq(url, ref, allow=True):
    # xbmc.log(f'[getUrlReq] {url=} {ref=} {allow=}',1)
    # allow = False
    #global mybtn_user
    if os.path.isfile(COOKIEFILE):
        sess.cookies.load()
        pass
    ab = sess.cookies
    
    headersy = {'User-Agent': UA, 'Referer': ref}
    if other_sess_mode:
        headersy={'User-Agent': UA, 'Referer': ref, 'Cookie': COOKIES,}
    sess.headers.update({
            'Host': 'filman.cc',
            'User-Agent': UA,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Referer': ref,
            'Upgrade-Insecure-Requests': '1',
            })
    if other_sess_mode:
        sess.headers.update({'Cookie': COOKIES,})       

    xbmc.log(f'{url=}', 0)
    content = sess.get(url, verify=False, cookies=sess.cookies, allow_redirects=allow)#.text
    # content=sess.get(url, verify=False, allow_redirects=allow)#.text
    
    if not content:
        # xbmc.log(f'{content=}',1)
        xbmcgui.Dialog().notification('[COLOR red][B]Błąd serwera[/B][/COLOR]: '+str(content.status_code), str(content.reason), xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmc.sleep(3000)
        # raise Exception()
        content.raise_for_status()

    # xbmc.log(f'{content.status_code=} \n{content.url=} \n{content.is_redirect=} \n{content.is_permanent_redirect=} \n{content.history=} \n{content.next=} \n{content.links=} \n{content.headers=} \n{content.cookies=}',1)
    if unquote(content.url) != url:
        xbmc.log(f'[getUrlReq] {url=} {content.url=}',1)
        pass

    if 'Security Check' in content.text:
        xbmc.log(f'jakiś Security Check',1)
        content = sess.get(url, headers=headersy)#.text    
        sess.cookies.save(COOKIEFILE, ignore_discard=True)

    if allow:
        content = content.text
    else:
        content = content

    mybtn_user = ''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
    # xbmc.log(f'DUPA {content=}',1)
    return content    #.text



def getTvs(url):
    global mybtn_user
    mybtn_user = args.get('token', [''])[0]
    cuk = quote(mybtn_user)
    content = getUrlReq(url, url)
    out = []
    result = parseDOM(content, 'div', attrs={'class': "row tv-list"})[0]
    links = parseDOM(result, 'div', attrs={'class': "col-xs-6 col-sm-3"})
    for link in links:
        src = parseDOM(link, 'img', ret='src')[0]
        href = parseDOM(link, 'a', ret='href')[0]   
        title = parseDOM(link, 'a', ret='title')[0]  
        if href and title:
            if src.startswith('//'):
                src = 'http:' + src
            film = {
                'href'   : href,
                'title'  : title,
                'plot'   : '',
                # 'img'    : src+'|User-Agent='+quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
                'img'    : src,
                }
            out.append(film)
    return out        



def getEpg(url):
    content = getUrl(url)
    plot = ''
    trwa = parseDOM(content, 'b')[0]
    czastrwa = parseDOM(content, 'p')[1]
    czastrwado = parseDOM(content, 'p')[2]
    dalej = parseDOM(content, 'table', attrs={'width': ".+?"})[0]
    plot += '[COLOR khaki]' + czastrwa + '-' + czastrwado + '[/COLOR] ' + trwa
    plot += '[CR]'
    try:
        typhourtitle = re.findall(r'<tr.+?title="(.+?)".+?<b>(.+?)<\/b.+?<td>(.+?)<\/td', dalej)#[0]
        for typ, hour, title in typhourtitle:
            plot += '[COLOR khaki]' + hour + '[/COLOR] ' + title
            plot += '[CR]'
    except:
        pass
    return plot



def getTvLink(url,imag):
    zalog = my_addon.getSetting('zalog')
    global mybtn_user
    
    mybtn_user = args.get('token',[''])[0]
    cuk = quote(mybtn_user)

    content=getUrlReq(url, url)
    out = []
    epgresult = parseDOM(content, 'div', attrs={'class': "epg"})#[0]
    plot = ''
    if epgresult:
        epgs = parseDOM(epgresult[0],'h4')
        if epgs:
            for epg in epgs:
                plot += '[COLOR khaki]'+epg+'[/COLOR] '
                plot += '[CR][CR]'
        else:
            epgs = parseDOM(epgresult[0],'span')
            if epgs:
                for epg in epgs:
                    plot += '[COLOR khaki]'+epg+'[/COLOR] '
                    plot += '[CR][CR]'                
    result = parseDOM(content, 'div', attrs={'class': "tab-content"})#[0]

    if result:
        result = result[0]
        co = 1    

        if 'tylko dla zalogowanych' in result:
            u = my_addon.getSetting('user')
            p = my_addon.getSetting('pass')

            logged, dane = getLogin(u, p)
            content = getUrlReq(url, url)
        tthrefs = re.findall('<iframe.+?src="(.+?)".+?"text-center">([^<]+).+?"text-center">([^<]+)', result, re.DOTALL)
        
        ids = [(a.start(), a.end()) for a in re.finditer('<div role="tabpanel"', result)]
        ids.append( (-1,-1) )
        out = []
        for i in range(len(ids[:-1])):

            odtw = result[ ids[i][1]:ids[i+1][0] ]
            if 'tab-pane fade" id="' in odtw:

                ab=re.findall('id="([^"]+).*?var player(.+?)watermark',odtw,re.DOTALL)
                if ab:
                    tyt = fname + ' - ' +ab[0][0]
                    info = tyt
                    href = re.findall(r'source\:\s*"([^"]+)',ab[0][1],re.DOTALL)[0]
                    link = url
                    film = {'href': href+'|User-Agent='+UA+'&Referer='+link, 'title': info, 'plot': plot, 'img': imag,}    
                    out.append(film)
            else:
                continue

    return out
    


def getMovies(url, page=1, group=''):
    # xbmc.log(f'[getMovies] {url=} {page=} {group=}',1)
    global mybtn_user
    mybtn_user = args.get('token', [''])[0]
    cuk=quote(mybtn_user)

    if '?page=' in url:
        url = url.replace('?page=', '?page=%d' % page)
    elif page:
        url += '/' if url[-1] != '/' else ''
        url = url + '?page=%d' % page
    if group:
        url = url.split('?')[0]    

    # xbmc.log(f'[getMovies] {url=}',1)
    content = getUrlReq(url, url)

    out = []
    gr = False
    pr = False
    ids = []
    try:
        result = parseDOM(content, 'div', attrs={'class': "col-sm-9"})[1]
    except:
        result = content        #<ul class='clearfix pagination'>

    mdata = parseDOM(content, 'ul', attrs={'class': "clearfix pagination"})#[0]     #<ul class='clearfix pagination'>
    mdata = unquote(mdata[0]) if mdata else content
    gr = False
    
    if mdata.find( '?page=%d' % (page+1)) > -1:
        gr = page + 1

    last_page = parseDOM(mdata, 'li', attrs={'class': "next"})
    # xbmc.log(f'[getMovies] {last_page=}',1)
    if last_page:
        last_page = last_page[-1]
        last_page = re.search(r"data-pagenumber='(\d*)'", last_page)
        if last_page:
            last_page = int(last_page[1])
    # xbmc.log(f'[getMovies] {last_page=}',1)

    links = parseDOM(result, 'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"}) #[0]    col-xs-6 col-sm-3 col-lg-2 #<ul class='clearfix pagination'>        links=
    for link in links:
        src = parseDOM(link, 'img', ret='src')[0]
        href = parseDOM(link, 'a', ret='href')[0]   
        plot = parseDOM(link, 'a', ret='data-text')#[0]
        try:
            # title = parseDOM(link, 'div', attrs={'class': "title"})[0]  # to juz nie obowiązuje
            title = parseDOM(link, 'h1', attrs={'class': "film_title"})[0]
        except:
            # xbmc.log(f'[getMovies] awaryjne title',1)
            try:
                title = parseDOM(link, 'a', ret='title')[0]
            except:
                title = "brak tytułu!"
        # originaltitle = title.split(" / ", 1)[-1]
        # title = title.replace(" / " + originaltitle, "", 1)
        # albo
        # titles = title.split(" / ")
        # title = titles[0]
        # originaltitle = titles[-1]
        # englishtitle = titles[1] if len(titles)>1 else ""
        try:
            rating = parseDOM(link, 'div', attrs={'class': "rate"})[0]
            # xbmc.log(f'[getMovies] {rating=}',1)
            m = re.match(r"(\d+\.?\d*) \((\d+)\)", rating)
            rating, votes = m[1], m[2]
        except:
            rating = ''
            votes = ''
        try:
            year = int(parseDOM(link, 'div', attrs={'class': "film_year"})[0])
        except:
            year = ''
        if href and title:
            if src.startswith('//'):
                src = 'http:' + src
            film = {
                'href'   : href,
                'title'  : fixSC(title),
                # 'originaltitle': fixSC(originaltitle),
                'plot'   : fixSC(plot[0]) if plot else '',
                # 'img'    : src+'|User-Agent='+quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
                'img'    : src,
                # "userrating": rating,  # eksperyment
                'rating' : rating,
                'votes'  : votes,
                'year'   : year,
                "mediatype": 'movie',
                # "mediatype": 'video',  # ewentualny fix dla yatse (ale nie pamiętam, czy to nie dotyczy tylko źródeł w katalogu
                # ale czy te typy w czymś pomagają? chyba dla niektórych skórek
                    }
            out.append(film)
        pr = page - 1 if page > 1 else False

    return (out, (pr,gr,last_page))    


    
def getSeries(url, page=1, group=''):
    # xbmc.log(f'[getSeries] {url=} {page=} {group=}',1)
    global mybtn_user
    mybtn_user = args.get('token', [''])[0]
    cuk = quote(mybtn_user)
    if '?page=' in url:
        url = url.replace('?page=', '?page=%d' %page)
    else:
        url += '/' if url[-1] != '/' else ''
        url = url + '?page=%d' %page
    if group:
        url = url.split('?')[0]
    content = getUrlReq(url, url)
    out = []
    gr = False
    pr = False
    ids = []

    if group:
        xbmc.log(f'[getSeries] {group=}',1)
        result = parseDOM(content, 'div', attrs={'id': "item-list", "class": "row series-list"}) 
        if 'Ostatnio dodane' in group:
            result = result[0]
        #else:
        #    result = result[1]
            
        links = parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"}) 
        for link in links:
            src = parseDOM(link, 'img', ret='src')[0]
            href = parseDOM(link, 'a', ret='href')[0]
            plot = parseDOM(link, 'a', ret='data-text')#[0]
            # title = parseDOM(link,'div', attrs={'class': "title"})#[0]  # to juz nie obowiązuje
            title = parseDOM(link, 'h1', attrs={'class': "film_title"})#[0]
            title2 = parseDOM(link,'a', ret='title')#[0]  
            title = title[0] if title else title2[0]
            try:
                rating = parseDOM(link, 'div', attrs={'class': "rate"})[0]
                # xbmc.log(f'[getMovies] {rating=}',1)
                m = re.match(r"(\d+\.?\d*)(?: \((\d*)\))?", rating)
                rating, votes = m[1], m[2]
            except:
                rating = ''
                votes = ''
            try:
                year = int(parseDOM(link, 'div', attrs={'class': "film_year"})[0])
            except:
                year = ''
            if href and title:
                if src.startswith('//'):
                    src = 'http:'+src
                film = {
                    'href'   : href,
                    'title'  : fixSC(title),
                    'plot'   : fixSC(plot[0]) if plot else '',
                    # 'img'    : src+'|User-Agent='+quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
                    'img'    : src,
                    'rating' : rating,
                    'votes'  : votes,
                    'year'   : year,
                    "mediatype": 'tvshow',
                        }
                out.append(film)    
    else:
        # xbmc.log(f'[getSeries] {group=}',1)
        '''
        result = parseDOM(content,'div', attrs={'class': "col-sm-9"})[1]     
        mdata = parseDOM(content,'div', attrs={'id': "item-list","class":"row series-list"}) [0]     
        mdata = unquote(mdata) if mdata else content
        gr = False
        '''
        try:
            result = parseDOM(content,'div', attrs={'class': "col-sm-9"})[1]
        except:
            result = content        #<ul class='clearfix pagination'>

        mdata = parseDOM(content,'ul', attrs={'class': "clearfix pagination"})#[0]     #<ul class='clearfix pagination'>
        mdata = unquote(mdata[0]) if mdata else content
        gr = False
        if mdata.find( '?page=%d' % (page+1)) > -1:
            gr = page+1    

        last_page = parseDOM(mdata, 'li', attrs={'class': "next"})
        # xbmc.log(f'[getSeries] {last_page=}',1)
        if last_page:
            last_page = last_page[-1]
            last_page = re.search(r"data-pagenumber='(\d*)'", last_page)
            if last_page:
                last_page = int(last_page[1])
        # xbmc.log(f'[getSeries] {last_page=}',1)

        links = parseDOM(result,'div', attrs={'class': "col-xs-6 col-sm-3 col-lg-2"}) 
        for link in links:
            src = parseDOM(link, 'img', ret='src')[0]
            href = parseDOM(link, 'a', ret='href')[0]
            plot = parseDOM(link, 'a', ret='data-text')#[0]
            title = parseDOM(link,'div', attrs={'class': "title"})#[0]  # to juz nie obowiązuje
            title = parseDOM(link, 'h1', attrs={'class': "film_title"})#[0]
            title2 = parseDOM(link,'a', ret='title')#[0]
            title = title[0] if title else title2[0]
            try:
                rating = parseDOM(link, 'div', attrs={'class': "rate"})[0]
                # xbmc.log(f'[getMovies] {rating=}',1)
                m = re.match(r"(\d+\.?\d*)(?: \((\d*)\))?", rating)
                rating, votes = m[1], m[2]
            except:
                rating = ''
                votes = ''
            try:
                year = int(parseDOM(link, 'div', attrs={'class': "film_year"})[0])
            except:
                year = ''
            if href and title:
                if src.startswith('//'):
                    src = 'http:'+src
                film = {
                    'href'   : href,
                    'title'  : fixSC(title),
                    'plot'   : fixSC(plot[0]) if plot else '',
                    # 'img'    : src+'|User-Agent='+quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
                    'img'    : src,
                    'rating' : rating,
                    'votes'  : votes,
                    'year'   : year,
                    "mediatype": 'tvshow',
                        }
                out.append(film)        
        pr = page - 1 if page > 1 else False

    return (out, (pr,gr,last_page))



def parseVideoLink(url, host=''):
    if 'cda' in host:
        return 'http://www.cda.pl/video/%s'%(url.split('id=')[-1])
    elif 'alltube' in url:
        content = getUrlReq(url,url)
        outurl = ''
        href = re.compile('src="(.*?)"').findall(content)
        if href:
            href = [h for h in href if BRAMKA not in h]
            outurl = getHref(href[0])
            if outurl.startswith('//'):
                outurl = 'http:'+outurl
        return outurl
    elif str(host) in url:
        if url.startswith('//'):
            url = 'http:' + url
        return url
    else:
        return url



def getVideos(url, meta_data=None):
    # xbmc.log(f'[getVideos] {url=}', 1)
    content = getUrlReq(url, url)

    # xbmc.log(f'[getVideos] {url=}  {content=}', 1)

    out=[]
    # if "/m/" in url:
    title = parseDOM(content, 'span', attrs={'itemprop': "title"})
    tv_title = parseDOM(content, 'h2',)
    ep_title = ""
    if tv_title:
        title = tv_title
        # tv_title = tv_title[0]
        ep_title = parseDOM(content, 'h3',)
    else:
        # tv_title = ""
        pass
    ep_title = ep_title[0] if ep_title else ""
    title = title[0] if title else ""

    year = parseDOM(content, 'div', attrs={'class': "info"})
    # xbmc.log(f'[getVideos] {len(year)=} {year=}',1)
    if year:
        year = parseDOM(year, 'li')
        year = year[1] if year else 0
    else:
        if meta_data and meta_data.get('tvshowyear'):
            year = meta_data.get('tvshowyear')
        else:
            year = 0  # a czemu 0 a nie "" ?

    plot = parseDOM(content, 'p', attrs={'class': "description"})
    plot = plot[0] if plot else ""
    plot = plot.replace("czytaj dalej", "")

    try:
        rating = parseDOM(content, 'span', attrs={'itemprop': "ratingValue"})[0]
        votes = parseDOM(content, 'span', attrs={'itemprop': "reviewCount"})[0]
    except:
        rating = votes = ""

    try:
        genre = parseDOM(content, 'li', attrs={'itemprop': "genre"})
        # xbmc.log(f'[getVideos] {len(genre)=} {genre=}',1)
        genre = " / ".join(genre)
        genre = stripHTMLTags(genre)
        # xbmc.log(f'[getVideos] {genre=}',1)
    except:
        genre = ""
    if meta_data and meta_data.get('genre'):
        genre = meta_data.get('genre')

    try:
        pass
        country = parseDOM(content, 'ul', attrs={'class': "country"})[0]
        # xbmc.log(f'[getVideos] {country=}',1)
        country = parseDOM(country, 'li')[1:]
        # xbmc.log(f'[getVideos] {len(country)=} {country=}',1)
        country = " /".join(country)
        country = stripHTMLTags(country)
        # xbmc.log(f'[getVideos] {country=}',1)
    except:
        country = ""
    if meta_data and meta_data.get('country'):
        country = meta_data.get('country')


    try:
        director = parseDOM(content, 'ul', attrs={'itemprop': "director"})[0]
        director = stripHTMLTags(director)
        director = director.replace("\n", "").strip()
        # xbmc.log(f'[getVideos] {director=}',1)
        pass
    except:
        director = ""
        pass

    # xbmc.log(f'[getVideos] {title=} {ep_title=} {year=} \n {plot=} \n {rating=} {votes=}', 1)
    try:
        result = parseDOM( (parseDOM(content, 'table', attrs={'id': "links"})[0]), 'tbody' )
        hrefok = ''
        if result:
            # xbmc.log(f' {result[0]=}', 1)
            links = re.findall('"link-to-video">(.+?)td class="vote', result[0], re.DOTALL)
            if not links:
                # xbmc.log(f' {links=}', 1)
                # links = re.findall('"link-to-video">(.+?)<\/td', result[0], re.DOTALL)
                links = re.findall(r'"link-to-video">(.+?)<\/tr', result[0], re.DOTALL)

            # xbmc.log(f'[getVideos] {len(links)=}',1)
            for link in links:
                # xbmc.log(f'{link=}',1)

                if 'bez limitów' in link.lower():
                    # xbmc.log(f'link premium {link=}',1)
                    iframe = re.findall('a href="([^"]+)"', link)
                    # xbmc.log(f'link premium {iframe=}',1)
                    prem2 = True
                else:
                    iframe = re.findall(r'data\-iframe="([^"]+)"', link)
                    prem2 = False

                try:
                    decodiframe = base64.b64decode(iframe[0])
                    decodiframe = decodiframe.decode(encoding='utf-8', errors='strict') if sys.version_info >= (3,0,0) else decodiframe
                    decodiframe = decodiframe.replace(r'\/','/')
                    # xbmc.log(f'\n[filmancc] {decodiframe=}',1)
                    if prem2:
                        # xbmc.log(f'\n[filmancc] {decodiframe=}',1)
                        dod = re.findall(r"""attr\(\\'href\\'\)\)\s*\+\s*\\'(.+?)\\'""", content, re.DOTALL)  # nie rozumiem tego
                        if dod:
                            # nie pamiętam dla jakich to przypadków
                            dod = dod[0]  # nie jestem tego pewien
                            # dod = ""  # bo może jednak tak powinno byc ?
                            # xbmc.log(f'do premium {dod=}',1)
                        else:
                            dod = ""
                        dod += '|referer=https://filman.cc/&user-agent=Mozilla'
                        hrefok = decodiframe + dod
                        # xbmc.log(f'[getVideos] link premium {hrefok=}',1)
                    else:
                        hrefok = re.findall(r"""src['"]:['"](.+?)['"]\,""", decodiframe)[0]
                        # xbmc.log(f'link {hrefok=}',1)
                    info = ''.join(re.compile('>(.*?)<', re.DOTALL).findall(link))
                    info = re.sub(' {2,}', ' | ', fixSC(info))#.strip()
                    info = re.sub(r'\(.+?\)', '', info)
                    info = info.replace(' dodane ', ' | dodane ')
                    info = info.replace('dodane ', '')
                    info = info.strip(" |")
                    cols = info.split(' | ')
                    if hrefok:
                        if prem2:
                            info = f"[B]{info}[/B]"
                        film = {
                                'url': hrefok,
                                'label': info,
                                'quality': cols[-1],
                                'ago': cols[1].replace('dodane ', ''),
                                }
                        # xbmc.log(f'[getVideos] {film=}', 1)
                        out.append(film)
                except Exception:
                    pass

            if not links:
                czy_konto_premium = my_addon.getSetting('prem')
                if 'true' in czy_konto_premium:
                    xbmc.log(f'[getVideos] brak linków',1)
                else:
                    xbmc.log(f'[getVideos] brak linków, lub jest tylko link premium, do którego nie masz uprawnień',1)
    except:
        pass

    # xbmc.log(f'[getVideos] {len(out)=}', 1)
    # xbmc.log(f'[getVideos] {out=}', 1)
    out = sort_by_ago(out)

    # mediatype = "movie" if "/m/" in url else "tvshow" if "/s/" in url else "episode" if "/e/" in url else ""
    # xbmc.log(f'[getVideos] {mediatype=}', 1)
    # mediatype = "movie" if not ep_title else "episode"
    # xbmc.log(f'[getVideos] {mediatype=}', 1)

    meta = {
            'title': fixSC(title),  # if not ep_title else ep_title
            'ep_title': fixSC(ep_title),  # wówczas byłoby niepotrzebne
            # 'tvshowtitle': fixSC(tv_title) if ep_title else '',
            'year': year,
            'plot': fixSC(plot),
            'rating' : rating,
            'votes': votes,
            'genre': genre,
            "country": country,
            "director": director,
            # "writer": writer,
            # "mediatype": mediatype,  # czy to w czymś pomaga? bo nie wiem
            # "cast": cast,
            }
    # xbmc.log(f'[getVideos] {meta=}', 1)

    return out, meta



def scanEpisodes(url):
    global mybtn_user
    mybtn_user = args.get('token', [''])[0]
    cuk = quote(mybtn_user)
    content = getUrlReq(url, url)
    src = re.compile('<ul id="episode-list">(.*?)</ul>').findall(content)
    src = src[-1] if src else ''
    out = []
    odcinki = content.find('Odcinki')
    odcinek = content.find('Dodaj odcinek')
    gdzie = re.findall('Odcinki(.+?)Dodaj odcinek', content, re.DOTALL)[0]
    if 'ten serial nie posiada' in gdzie:
        return out
    links = re.compile('<a href="(.*?)">(.*?)</a>', re.DOTALL).findall(gdzie)
    imgsrc = re.compile('class="col-sm-3">(.+?)<div', re.DOTALL).findall(content)    
    imgsrc = imgsrc[1] if imgsrc else ''
    imgsrc = re.compile('<img src="(.*?)"', re.DOTALL).findall(imgsrc)
    # imgsrc = imgsrc[-1]+'|User-Agent='+quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk if imgsrc else ''
    imgsrc = imgsrc[-1] if imgsrc else ''
    info = parseDOM(content, 'div', attrs={'class': "info"})
    # xbmc.log(f'[scanEpisodes] {len(info)=} {info=}',1)
    if info:
        year = parseDOM(info, 'li')
        # xbmc.log(f'[scanEpisodes] {len(year)=} {year=}',1)
        year = year[1] if year else 0
    else:
        year = ""
    # xbmc.log(f'[scanEpisodes] {year=}',1)

    tv_title = parseDOM(content, 'h2',)
    tv_title = tv_title[0] if tv_title else ''

    try:
        genre = parseDOM(content, 'li', attrs={'itemprop': "genre"})
        # xbmc.log(f'[scanEpisodes] {len(genre)=} {genre=}',1)
        genre = " / ".join(genre)
        genre = stripHTMLTags(genre)
        # xbmc.log(f'[scanEpisodes] {genre=}',1)
    except:
        genre = ""

    try:
        pass
        country = parseDOM(content, 'ul', attrs={'class': "country"})[0]
        # xbmc.log(f'[scanEpisodes] {country=}',1)
        country = parseDOM(country, 'li')[1:]
        # xbmc.log(f'[scanEpisodes] {len(country)=} {country=}',1)
        country = " /".join(country)
        country = stripHTMLTags(country)
        # xbmc.log(f'[scanEpisodes] {country=}',1)
    except:
        country = ""

    for h,t in links:
        t = fixSC(t.strip())
        t = re.sub(' +',' ',t)
        data = re.compile(r'[sS](\d+)[Ee](\d+)').findall(t)
        film = {
            'href' : h.strip(),
            'title' : fixSC(t),
            # 'plot' : fixSC(t),  # nie ma skąd wziąść opisu odcinka w tym miejscu (opis odcinka dostępny jest dopiero przy źródłach)
            'img' : imgsrc,
            'season' : int(data[0][0]) if data else '',
            'episode' : int(data[0][1]) if data else '',
            # 'aired' : '',
            'tvshowyear': year,
            'tvshowtitle': fixSC(tv_title),
            'genre': genre,
            'country': country,
            "mediatype": "episode",
            }
        out.append(film)
    # xbmc.log(f'[scanEpisodes] {out=}', 1)
    return out



def splitToSeasons(dinput):
    out={}
    seasons = [x.get('season') for x in dinput]
    for s in set(seasons):
        out['Sezon %02d'%s]=[dinput[i] for i, j in enumerate(seasons) if j == s]
    return out


def getComments(url):
    # xbmc.log(f'[getComments] {url=}', 1)
    busy()
    content = getUrlReq(url, url)
    # xbmc.log(f'[getComments] {url=}  {content=}', 1)
    try:
        opis = parseDOM(content, 'p', attrs={'class': "description"})[0]
    except:
        opis = ""
    try:
        srednia_ocena = parseDOM(content, 'span', attrs={'itemprop': "ratingValue"})[0]
        ilosc_glosow = parseDOM(content, 'span', attrs={'itemprop': "reviewCount"})[0]
    except:
        srednia_ocena = ilosc_glosow = ""
    comments = parseDOM(content, 'div', attrs={'id': "comments"})
    # comments = parseDOM(comments, 'div', attrs={'class': "comment clearfix"})
    users = parseDOM(comments, 'b',)
    comments = parseDOM(comments, 'p', attrs={'class': "text-justify.+?"})
    # xbmc.log(f'[getComments] {len(comments)=}  \n{comments=} \n{users=}', 1)
    # out = "\n\n".join(comments)
    out = ""
    if opis:
        # out += "[B]"
        # out += "[LIGHT]"
        out += f"{fixSC(opis)}\n\n"
        # out += "[/LIGHT]"
        # out += "[/B]"
        pass
    if srednia_ocena and ilosc_glosow:
        out += f"~[I]Średnia ocena ([LIGHT]wg użytkowników[/LIGHT]): [B]{srednia_ocena}[/B]  ([LIGHT]z[/LIGHT] [B]{ilosc_glosow}[/B] [LIGHT]oddanych głosów[/LIGHT])[/I]\n\n"
    if len(comments):
        for i, u in enumerate(users):
            out += f"\n[{u}]: \n[I][LIGHT]{unescape(stripHTMLTags(comments[i].replace('<br />', ''), exclude='n'))}[/LIGHT][/I]\n\n"
    else:
        out += "\nBRAK KOMENTARZY"
    idle()
    xbmcgui.Dialog().textviewer('Opis i Komentarze użytkowników', out)
    # return out


def stripHTMLTags(html, exclude=""):
    html = re.sub(r"\s*\w+\s*=\s*([\"']?).*?\1(?=[\s>]|$)\s*", "", html)
    html = re.sub("<[^>]+>", "", html)
    return html


def getSort(mv='film', sc='category'):
    label = []
    value = []
    if mv == 'film':
        url='https://filman.cc/filmy/'
        content = getUrlReq(url, BASEURL)
        if sc == 'category':
            result = parseDOM(content,'ul', attrs={'id': "filter-category"})[0]
            value = parseDOM(result,'li', ret='data-id') #[0]
            label = parseDOM(result,'a')
        elif sc == 'year':
            result = parseDOM(content,'ul', attrs={'id': "filter-year"})[0]
            value = parseDOM(result,'li', ret='data-id') #[0]
            label = parseDOM(result,'a')
        # elif sc == 'country': 
            # result = parseDOM(content,'ul', attrs={'id': "filter-country"})[0]
            # value = parseDOM(result,'li', ret='data-id') #[0]
            # result = re.sub('    HiszpaniaWielka Brytania', 'Hiszpania/Wielka Brytania', result)
            # result = re.sub(r'\s+', ' ', result)
            # label = parseDOM(result,'a')
    elif mv == 'serial':
        url='https://filman.cc/seriale/'
        content = getUrlReq(url, BASEURL)
        if sc == 'category':
            result = parseDOM(content,'ul', attrs={'id': "filter-category"})[0]
            value = parseDOM(result,'li', ret='data-id') #[0]
            label = parseDOM(result,'a')
    return (label, value)



def search(pharse='dom'):
    # xbmc.log(f'[search] {pharse=}',1)
    global mybtn_user
    mybtn_user = args.get('token', [''])[0]
    cuk = quote(mybtn_user)
    if "://" in pharse:
        url = pharse
    else:
        url = 'https://filman.cc/item?phrase=' + pharse
    content = getUrlReq(url, BASEURL)
    out1 = []  # na filmy
    out2 = []  # na seriale
    result = parseDOM(content, 'div', attrs={'id': "advanced-search"})
    if result:
        result = result[0]
    else:
        result = content
    links = parseDOM(result, 'div', attrs={'class': "poster"})
    # xbmc.log(f'[search] {len(links)=} ',1)
    years = parseDOM(result, 'div', attrs={'class': "film_year"})
    # titles = parseDOM(result, 'h1', attrs={'class': "film_title"})  # można by wykorzystać
    # xbmc.log(f'[search] {len(links)=} {len(years)=} {len(titles)=}',1)  # uwaga na zmienną titles (czy nie zakomentowana)
    zgodnosc = len(links) == len(years)
    # xbmc.log(f'[search] {zgodnosc=}',1)
    if not zgodnosc:
        posters = parseDOM(result, 'div', attrs={'class': "col-xs-6 col-sm-2"})
        # xbmc.log(f'[search] {len(posters)=} ',1)
        if len(links) == len(posters):
            links = posters
    # for link in links:
    for i, link in enumerate(links):
        # xbmc.log(f'[search] {i=} {link=}',1)
        src = parseDOM(link, 'img', ret='src')[0]
        src = src.replace('thumb', 'big')
        href = parseDOM(link, 'a', ret='href')[0]
        # xbmc.log(f'[search] {i=} {href=}',1)
        try:
            year = str(int(href[-4:]))
        except:
            try:
                year = parseDOM(link, 'div', attrs={'class': "film_year"})[0]
            except:
                year = ''
        # title = parseDOM(link,'a', ret='data-title')[0]  # bywa ucięty
        # title = parseDOM(link, 'div', attrs={'class': "title"})[0]  # nie zawsze występuje
        title = parseDOM(link, 'img', ret='alt')[0] 
        # title = titles[i] if zgodnosc else ''  # jak z rokiem
        plot = parseDOM(link, 'a', ret='data-text')[0] 
        try:
            rating = parseDOM(link, 'span', attrs={'style': "color: white"})[0]
            # xbmc.log(f'[search] {rating=}',1)
            m = re.match(r"(\d+\.?\d*) \((\d+)\)", rating)
            rating, votes = m[1], m[2]
        except:
            rating = ''
            votes = ''
        if href and title:
            mediatype = 'movie' if '/m/' in href else "tvshow"
            if src.startswith('//'):
                src = 'http:' + src
            item = {
                    'href' : href,
                    'title': fixSC(title),
                    'plot' : fixSC(plot),
                    # 'img'  : src+'|User-Agent='+quote(UA)+'&Referer='+mainurl+'&Cookie='+cuk,
                    'img'  : src,
                    'year': years[i] if zgodnosc else year,
                    'rating': rating,
                    'votes': votes,
                    "mediatype": mediatype,  # czy to w czymś pomaga? bo nie wiem
                   }
            if '/m/' in item['href']:  # film
                # if item not in out1:  # o dziwo nie sprawdziło się
                # if item['href'] not in [it['href'] for it in out1]:
                if not any(item['href'] == it['href']  for it in out1):
                    out1.append(item)
            else:#elif '/s/' in item['href']: /serial-online/
                if not any(item['href'] == it['href']  for it in out2):
                    out2.append(item)
    # xbmc.log(f'{len(out1)=}  out1={json.dumps(out1, indent=2)}',1)
    # xbmc.log(f'{len(out2)=}  out2={json.dumps(out2, indent=2)}',1)
    return out1, out2  # filmy, seriale



def fixSC(pharse, exclude=""):
    if isinstance(pharse, unicode):
        if sys.version_info >= (3,0,0):
            pharse = pharse
        else:
            pharse = pharse.encode('utf-8')
    pharse = pharse.replace('&lt;br/&gt;', ' ')
   # s = 'JiNcZCs7'
   # pharse = re.sub(s.decode('base64'), '', pharse)
    if "\n" not in exclude and "n" not in exclude:
        pharse = pharse.replace('\n','').replace('\r','').replace('\t','')
    pharse = pharse.replace('&nbsp;','')
    pharse = pharse.replace('&quot;','"').replace('&amp;quot;','"')
    pharse = pharse.replace('&oacute;','ó').replace('&Oacute;','Ó')
    pharse = pharse.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    pharse = pharse.replace('&amp;','&')
    pharse = pharse.replace('\u0105','ą').replace('\u0104','Ą')
    pharse = pharse.replace('\u0107','ć').replace('\u0106','Ć')
    pharse = pharse.replace('\u0119','ę').replace('\u0118','Ę')
    pharse = pharse.replace('\u0142','ł').replace('\u0141','Ł')
    pharse = pharse.replace('\u0144','ń').replace('\u0143','Ń')
    pharse = pharse.replace('\u00f3','ó').replace('\u00d3','Ó')
    pharse = pharse.replace('\u015b','ś').replace('\u015a','Ś')
    pharse = pharse.replace('\u017a','ź').replace('\u0179','Ź')
    pharse = pharse.replace('\u017c','ż').replace('\u017b','Ż')
    return pharse


# Mnożniki jednostek czasu w sekundach
TIME_UNITS = {
    "bez": 1,
    "minutę": 60,
    "minuty": 60,
    "minut": 60,
    "godzinę": 3600,
    "godziny": 3600,
    "godzin": 3600,
    "dzień": 86400,
    "dni": 86400,
    "tydzień": 604800,
    "tygodnie": 604800,
    "tygodni": 604800,
    "miesiąc": 2592000,
    "miesiące": 2592000,
    "miesięcy": 2592000,
    "rok": 31536000,
    "lata": 31536000,
    "lat": 31536000
}


# stworzone przez ChatGPT
def parse_time_string(time_str):
    """
    Przekształca słowny opis czasu w liczbę sekund temu.
    Obsługuje zarówno "1 rok temu", jak i "rok temu".
    """
    match = re.match(r"(?:\b(\d+)\b\s+)?(\w+)", time_str)
    # xbmc.log(f'[parse_time_string]  {match=}  {time_str=}',1)
    if not match:
        # xbmc.log(f'[parse_time_string]  Nieznany format  {time_str=}',1)
        return float('inf')  # Nieznany format – wrzucamy na koniec
    value, unit = match.groups()
    value = int(value) if value else 1  # Domyślnie 1, jeśli brak liczby
    multiplier = TIME_UNITS.get(unit, None)
    if multiplier is None:
        # xbmc.log(f'[parse_time_string]  {multiplier=}  {time_str=}',1)
        return float('inf')
    # xbmc.log(f'[parse_time_string]  {value=} * {multiplier=}  {time_str=}',1)
    return value * multiplier


def sort_by_ago(data, key="ago"):
    """
    Sortuje listę słowników według czasu w polu 'key' (np. 'ago').
    """
    # xbmc.log(f'[sort_by_ago] sortowanie wg najnowszych',1)
    # return sorted(data, key=lambda x: parse_time_string(x[key]))
    return sorted(data, key=lambda x: (parse_time_string(x[key]), -int(x['quality'].replace('p',''))) )
    

def busy():
    Kodi = xbmc.getInfoLabel("System.BuildVersion")[:2]
    try:
        Kodi = int(Kodi)
        if Kodi > 17:
            if not xbmc.getCondVisibility("Window.IsActive(busydialognocancel)") and not xbmc.getCondVisibility("Window.IsActive(busydialog)"):
                xbmc.executebuiltin("ActivateWindow(busydialognocancel)")  # Kodi 18
        else:
            if not xbmc.getCondVisibility("Window.IsActive(busydialog)"):
                xbmc.executebuiltin("ActivateWindow(busydialog)")  # Kodi 17
    except Exception:
        pass


def idle(mode=0):
    if mode != 2 and xbmc.getCondVisibility("Window.IsActive(busydialog)"):
        xbmc.executebuiltin("Dialog.Close(busydialog)")  # Kodi 17
    if mode != 1 and xbmc.getCondVisibility("Window.IsActive(busydialognocancel)"):
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")  # Kodi 18


mode = args.get('mode', None)


sortv    = my_addon.getSetting('sortV')  # wartość
sortn    = my_addon.getSetting('sortN') if sortv else 'Nowe linki'  # napis

sortv_s  = my_addon.getSetting('sortV_s')
sortn_s  = my_addon.getSetting('sortN_s') if sortv_s else 'Nowe odcinki'

qualityv = my_addon.getSetting('qualityV')
qualityn = my_addon.getSetting('qualityN') if qualityv else 'Wszystkie'

versionv = my_addon.getSetting('versionV')
versionn = my_addon.getSetting('versionN') if versionv else 'Wszystkie'



def router(paramstring):

    args = dict(parse_qsl(paramstring))
    # xbmc.log(f'[router] {args=}',1)
    ex_link = args.get('ex_link', None)
    rys = args.get('iconImage', None)
    # page = args.get('page', [1])[0]
    page = args.get('page', 1)
    last_page = args.get('last_page', 0)
    refresh = args.get('refresh')
    refresh = 0 if refresh == '0' else refresh

    if args:    
        mode = args.get('mode', '')

        if 'filtr:' in mode:
            myMode = mode.split(":")[-1]
            # xbmc.log(f'[router] {myMode=}',1)
            
            if myMode == 'sort':
                label = ['Filmy z Premium', 'Nowe linki', 'Daty dodania', 'Liczba głosów', 'Premiera',      'Odsłony',   'Ocena',     'Ocena FilmWeb']
                value = ['sort:direct',     'sort:link',  'sort:date',    'sort:vote',     'sort:premiere', 'sort:view', 'sort:rate', 'sort:filmweb']    
                msg = 'Sortowanie'

            if myMode == 'sort_s':
                label = ['Seriale z Premium', 'Nowe seriale', 'Nowe odcinki',    'Liczba głosów', 'Odsłony',   'Ocena', ]
                value = ['sort:direct',       'sort:date',    'sort:newepisode', 'sort:vote',     'sort:view', 'sort:rate']      
                msg = 'Sortowanie (dla seriali)'

            elif myMode == 'quality':
                label = ['Wszystkie', '360p', '480p', '720p', '1080p']
                value = ['', 'quality:1', 'quality:2', 'quality:3', 'quality:4']
                msg = 'jakość'

            elif myMode == 'version':
                label = ['Wszystkie', 'Dubbing',   'Dubbing Kino', 'ENG',       'Lektor',    'Lektor IVO', 'Napisy',    'Napisy_Tansl', 'PL']
                value = [''         , 'version:2', 'version:6',    'version:5', 'version:3', 'version:9',  'version:4', 'version:10',   'version:1']
                msg = 'wersje językowe'
                        
            if myMode in ['quality', 'version']:
                try:
                    # sel = xbmcgui.Dialog().select('Wybierz', label)  #l1l1l11ll11l1l11_nktv_
                    sel = xbmcgui.Dialog().multiselect(f'Wybierz {msg}', label)
                except:
                    # sel = xbmcgui.Dialog().select('Wybierz '+msg, label)
                    pass
                n = ''
                if isinstance(sel, list):
                    if 0 in sel:
                        sel=[0]
                    v = myMode+':'+','.join( [ value[i].replace(myMode+':', '') for i in sel])
                    n = ','.join( [ label[i] for i in sel])
                elif sel is not None:
                    if sel > -1:
                        v = value[sel]
                        n = label[sel]
                if n:
                    my_addon.setSetting(myMode+'V', v)
                    my_addon.setSetting(myMode+'N', n)
                    xbmc.executebuiltin('Container.Refresh')
            else:
                sel = xbmcgui.Dialog().select(msg, label)
                if sel > -1:
                    v = value[sel]
                    n = label[sel]
                    if "_s" in myMode:
                        myMode = myMode.replace("_s", "")
                        my_addon.setSetting(myMode+'V'+'_s', v)
                        my_addon.setSetting(myMode+'N'+'_s', n)
                    else:
                        my_addon.setSetting(myMode+'V', v)
                        my_addon.setSetting(myMode+'N', n)
                    xbmc.executebuiltin('Container.Refresh()')
                else:
                    pass

        
        elif mode == 'playTv':
            PlayTv(ex_link)
            xbmcplugin.setContent(addon_handle, 'movies')    
            xbmcplugin.endOfDirectory(addon_handle,True)


        elif mode == 'ListTv':
            listTv(ex_link)
            xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, labelMask="%L", label2Mask="%R, %Y, %P")
            xbmcplugin.setContent(addon_handle, 'movies')        
            xbmcplugin.endOfDirectory(addon_handle,True)


        elif mode == 'getTvLinks':
            getTvLinks(ex_link, rys)
            xbmcplugin.setContent(addon_handle, 'movies')
            xbmcplugin.endOfDirectory(addon_handle,True)


        elif mode == 'ListMovies':
            sr = '/'.join([x for x in [sortv, qualityv, versionv] if x]) if '/filmy/' in ex_link else ''
            sr = '' if sr in ex_link else sr
            listMovies(ex_link+sr, page, last_page)            
            xbmcplugin.setContent(addon_handle, 'movies')
            xbmcplugin.endOfDirectory(addon_handle,True)


        elif mode == 'ListMoviesKids':
            listMovies(ex_link, page, last_page)
            xbmcplugin.setContent(addon_handle, 'movies')

            xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_VIDEO_YEAR, labelMask="%L")
            xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING, labelMask="%L")
            xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_VIDEO_TITLE, labelMask="%L")
            # xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_PLAYLIST_ORDER, labelMask="%L")  # wykorzystywanie countera (jeśli ustawiono)
            xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, labelMask="%L")

            xbmcplugin.endOfDirectory(addon_handle,True)

            # xbmc.executebuiltin("Container.SetSortMethod(16)")  # rok
            # xbmc.log(f'{mode=} {dir(xbmcplugin)=}',1)    
            xbmc.sleep(100)
            # https://kodi.wiki/view/List_of_built-in_functions#List_of_sort_methods
            # xbmc.log(f'{mode=} {xbmc.getInfoLabel("Container.SortMethod")=}',1)
            # xbmc.log(f'{mode=} {xbmc.getCondVisibility("Container.SortMethod(16)")=}',1)
            # xbmc.log(f'{mode=} {xbmc.getCondVisibility("Container.SortMethod(17)")=}',1)
            # xbmc.log(f'{mode=} {xbmc.getCondVisibility("Container.SortMethod(7)")=}',1)
            if xbmc.getCondVisibility('Container.Sortmethod(16)') or xbmc.getCondVisibility('Container.Sortmethod(17)'):
                if xbmc.getCondVisibility('Container.SortDirection(ascending)'):
                    # xbmc.log(f'[listMovies] zmiana kierunku sortowania',1)
                    xbmc.executebuiltin("Container.SetSortDirection")  # Toggle the sort direction


        elif mode == 'Opcje':
            my_addon.openSettings()
            xbmc.executebuiltin('Container.Refresh()')

        
        elif mode == '__page__M':
            url = build_url({'mode': 'ListMovies',  'foldername': '', 'ex_link': ex_link, 'page': page})
            xbmc.executebuiltin('Container.Update(%s)'% url)

        
        elif mode == '__page__S':
            url = build_url({'mode': 'ListSeriale', 'foldername': '', 'ex_link': ex_link, 'page': page})
            xbmc.executebuiltin('Container.Update(%s)'% url)


        elif mode == 'selectTitleToFanFilm':
            mtype = args.get('mtype')
            title = args.get('title')
            year = args.get('year')
            q = zapytaj_co_wyslac_do_FF(title, year)
            if q:
                xbmc.executebuiltin('Container.Update(plugin://%s?action=%sSearchterm&name=%s)' % (FanFilmAddonId, mtype, quote_plus(q)))

        
        elif mode == 'getEpisodes':
            getEpisodes(ex_link)

        
        elif mode == 'getEpisodes2':
            getEpisodes2(ex_link)

            
        elif mode == 'ListSeriale':
            listSeries(ex_link, page, last_page)
            if 'Ostatnio dodane seriale' in ex_link:
                xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, labelMask="%L", label2Mask="%R, %Y, %P")
                pass
            # xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, labelMask="%L", label2Mask="%R, %Y, %P")
            xbmcplugin.setContent(addon_handle, 'tvshows')
            xbmcplugin.endOfDirectory(addon_handle,True)


        # elif mode == 'ListPopulars':
            # pass
            # ListPopulars(ex_link)
            # xbmcplugin.endOfDirectory(addon_handle,True)


        elif mode == 'getSeasons':
            getSeasons(ex_link)

        
        elif mode == 'ListFS':  # FS to może być skrót od FilmSerial
            listFS(ex_link)
            # nie wiem, które będzie najlepsze, trzeba potestować
            # xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask="%R, %Y, %P")  # tu nie będzie się pokazywał atrybut label, tylko title
            # xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, labelMask="%L", label2Mask="%R, %Y, %P")  # powinien pokazywać się atrybut label
            # xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE, labelMask="%T", label2Mask="%R, %Y, %P")  # atrybut title
            # xbmcplugin.setContent(addon_handle, 'files')
            # xbmcplugin.endOfDirectory(addon_handle,True)


        elif mode == 'getLinks':
            getLinks(ex_link)

        
        elif mode == 'Komentarze':
            # xbmc.log(f'[router] \n{ex_link=}',1)
            getComments(ex_link)
            xbmcplugin.endOfDirectory(addon_handle, True)


        elif mode == 'DOWNLOAD':
            # xbmc.log(f'[router] {mode=} {ex_link=}',1)
            data = eval(ex_link)
            # xbmc.log(f'[router] {mode=} {data=}',1)
            download_path = my_addon.getSetting('download.path')
        
            if download_path:
                getLinks(data.get('href'), True, data.get('title'), data.get('img'), data)
            else:
                xbmcgui.Dialog().ok('Ustaw docelowy folder', 'Pobieranie nie powiodło się')
            xbmcplugin.endOfDirectory(addon_handle,True)


        elif mode == 'GatunekRok':
            param = ex_link.split('|')
            # xbmc.log(f'[router] {mode=} {param=}',1)
            label, value = getSort(mv=param[0], sc=param[1])
            #try:
            # sel = xbmcgui.Dialog().select('Wybierz', label)
            sel = xbmcgui.Dialog().multiselect('Wybierz', label)
            #except:
            # sel = None
            # sel = xbmcgui.Dialog().select('Wybierz', label)  # czemu to jest powtórzone?
            # pass
            # xbmc.log(f'[router] {mode=} {sel=}',1)
            v = ''
            if isinstance(sel, list):
                v = param[1]+':'+','.join([value[i] for i in sel])
            elif sel is not None:
                if sel > -1:
                    v = param[1] + ':' + value[sel]
            if v:
                # xbmc.log(f'[router] {mode=} {v=}',1)
                if 'film' in param[0]:
                    sr = '/'.join([x for x in [sortv, qualityv, versionv, v] if x])
                else:
                    sr = '/'.join([x for x in [sortv_s, v] if x])
                # xbmc.log(f'[router] {mode=} \n{param=}  {sr=}',1)
                if 'film' in param[0]:
                    listMovies('https://filman.cc/filmy/'+sr, 1)
                    xbmcplugin.setContent(addon_handle, 'movies')
                else:
                    listSeries('https://filman.cc/seriale/'+sr, 1)
                    xbmcplugin.setContent(addon_handle, 'tvshows')
                xbmcplugin.endOfDirectory(addon_handle,True)
            else:
                pass
                # xbmcplugin.endOfDirectory(addon_handle,True)  # niepotrzebne
                # xbmc.executebuiltin('Action(Back)')
                # xbmc.log(f'[router] {mode=} refresh',1)
                # xbmc.executebuiltin('Container.Refresh()')  # opcjonalne? chyba, że byłby włączony reuselanguageinvoker, to raczej tak, aby nie było wiecznego busy


        elif mode =='Szukaj':
            #global mybtn_user
            mybtn_user = args.get('token', [''])[0]
            addDir('[B][Nowe Szukanie ...][/B]', '', mode='SzukajNowe', iconImage='DefaultMovieTitle.png')
            history = getHistory()
            if not history == ['']:
                for entry in history:
                    contextmenu = []
                    contextmenu.append((u'Usuń z historii', 'Container.Refresh(%s)'% build_url({'mode': 'SzukajUsun', 'ex_link': entry, 'token': mybtn_user})),) #, 'token': mybtn_user})
                    contextmenu.append((u'Usuń całą historię', 'Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll', 'token': mybtn_user})),)
                    addDir(name=entry, ex_link=entry.replace(' ', '+'), mode='ListFS', fanart=None, contextmenu=contextmenu, iconImage='DefaultAddonsSearch.png')
            # xbmcplugin.setContent(addon_handle, 'files')
            xbmcplugin.endOfDirectory(addon_handle,True,cacheToDisc=False)


        elif mode =='SzukajNowe':
            d = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu/serialu', type=xbmcgui.INPUT_ALPHANUM)
            d = d.strip()
            if d:
                setHistory(d)
                ex_link = d.replace(' ', '+')
                listFS(ex_link)
                # xbmcplugin.setContent(addon_handle, 'tvshows')
                # xbmcplugin.endOfDirectory(addon_handle,True)


        elif mode =='SzukajUsun':
            remCache(ex_link)
            mybtn_user = args.get('token', [''])[0]
            xbmc.executebuiltin('Container.Refresh(%s)'%  build_url({'mode': 'Szukaj', 'token': mybtn_user}))
            xbmcplugin.endOfDirectory(addon_handle,True)


        elif mode == 'SzukajUsunAll':
            delHistory()
            mybtn_user = args.get('token', [''])[0]
            xbmc.executebuiltin('Container.Refresh(%s)'%  build_url({'mode': 'Szukaj', 'token': mybtn_user}))
            xbmcplugin.endOfDirectory(addon_handle,True)


        elif mode == 'folder':
            pass

    else:
        
        login(refresh)

        if 'true' not in my_addon.getSetting('mono'):
            # addDir(name="Telewizja (LIVE)", ex_link='https://filman.cc/telewizja-online-pl', page=1, mode='ListTv', iconImage='DefaultFolder.png', fanart=FANART)
            addDir('[COLOR yellow][I]SZUKAJ ...[/I][/COLOR]', '', mode='Szukaj', iconImage='DefaultAddonsSearch.png')
            # addDir(name="Popularne tytuły", ex_link='https://filman.cc/popularne', page=0, mode='ListPopulars', iconImage='DefaultVideoPlaylists.png')
            addDir(name="[COLOR lightgreen]Na czasie, na topie[/COLOR]", ex_link='https://filman.cc/online', page=0, mode='ListFS', iconImage='DefaultMusicTop100.png')
            addDir(name="[COLOR lightskyblue]Filmy [LIGHT](wszystkie)[/LIGHT][/COLOR]", ex_link='https://filman.cc/filmy/', page=1, mode='ListMovies', iconImage='DefaultMovies.png')
            addDir(name=" [LIGHT] - wg wybranych gatunków[/LIGHT]", ex_link='film|category', page=1, mode='GatunekRok', iconImage='DefaultGenre.png')
            addDir(name=" [LIGHT] - wg wybranego roku[/LIGHT]", ex_link='film|year', page=1, mode='GatunekRok', iconImage='DefaultYear.png')
            # addDir(name=" [LIGHT] - wg wybranego kraju[/LIGHT]", ex_link='film|country', page=1, mode='GatunekRok', iconImage='DefaultFolder.png', fanart=FANART)
            addDir(name="[COLOR cyan]Seriale [LIGHT](wszystkie)[/LIGHT][/COLOR]", ex_link='https://filman.cc/seriale/', page=1, mode='ListSeriale', iconImage='DefaultTVShows.png')
            addDir(name=" [LIGHT] - wg wybranych gatunków[/LIGHT]", ex_link='serial|category', page=1, mode='GatunekRok', iconImage='DefaultGenre.png')
            # addDir(name=" [COLOR lightgreen]Ostatnio dodane seriale[/COLOR]", ex_link='https://filman.cc/seriale/|Ostatnio dodane seriale', page=1, mode='ListSeriale', iconImage='DefaultRecentlyAddedEpisodes.png')
            # addDir(name=" Popularne seriale", ex_link='https://filman.cc/seriale/|Popularne seriale', page=1, mode='ListSeriale', iconImage='DefaultFolder.png')
            addDir(name="[COLOR darkorange]Dla dzieci[/COLOR]", ex_link='https://filman.cc/dla-dzieci-pl/', page=1, mode='ListMoviesKids', iconImage='DefaultAddonImages.png')
            # addDir(name="[COLOR magenta]Zaskocz mnie[/COLOR]", ex_link='https://filman.cc/zaskocz-mnie', page=0, mode='getMovie', iconImage='DefaultFolder.png')
            addLinkItem('[COLOR lightpink]Zaskocz mnie [LIGHT](losowy film)[/LIGHT][/COLOR]', 'https://filman.cc/zaskocz-mnie', 'getLinks', iconimage='DefaultAddon.png', fanart=None, IsPlayable=True, infoLabels={"title": "niespodzianka", "plot": "losowo wybrany film"})
            addLinkItem("[COLOR powderblue][I]jakość[/I] [LIGHT] flmów[/LIGHT]:[/COLOR] [B]"+qualityn+"[/B]", '', mode='filtr:quality', iconimage='DefaultAddonService.png')
            addLinkItem("[COLOR powderblue][I]wersje językowe[/I] [LIGHT] flmów[/LIGHT]:[/COLOR] [B]"+versionn+"[/B]", '', mode='filtr:version', iconimage='DefaultAddonService.png')
            addLinkItem("[COLOR powderblue][I]sortowanie[/I] [LIGHT] flmów[/LIGHT]:[/COLOR] [B]"+sortn+"[/B]", '', mode='filtr:sort', iconimage='DefaultAddonService.png')
            addLinkItem("[COLOR powderblue][I]sortowanie[/I] [LIGHT] seriali[/LIGHT]:[/COLOR] [B]"+sortn_s+"[/B]", '', mode='filtr:sort_s', iconimage='DefaultAddonService.png')
            addLinkItem('[I]-= inne [B]Opcje[/B] dodatku =-[/I]', '', 'Opcje', iconimage='DefaultAddonProgram.png', infoLabels={"":""})
        else:
            # addDir(name="Telewizja (LIVE)", ex_link='https://filman.cc/telewizja-online-pl', page=1, mode='ListTv', iconImage='DefaultFolder.png', fanart=FANART)
            addDir('[I]SZUKAJ ...[/I]', '', mode='Szukaj', iconImage='DefaultAddonsSearch.png')
            # addDir(name="Popularne tytuły", ex_link='https://filman.cc/popularne', page=0, mode='ListPopulars', iconImage='DefaultVideoPlaylists.png')
            addDir(name="Na czasie, na topie", ex_link='https://filman.cc/online', page=0, mode='ListFS', iconImage='DefaultMusicTop100.png')
            addDir(name="Filmy [LIGHT](wszystkie)[/LIGHT]", ex_link='https://filman.cc/filmy/', page=1, mode='ListMovies', iconImage='DefaultMovies.png')
            addDir(name=" [LIGHT] - wg wybranych [Kategorii][/LIGHT]", ex_link='film|category', page=1, mode='GatunekRok', iconImage='DefaultGenre.png')
            addDir(name=" [LIGHT] - wg wybranego [Roku][/LIGHT]", ex_link='film|year', page=1, mode='GatunekRok', iconImage='DefaultYear.png')
            # addDir(name=" [LIGHT] - wg wybranego [Kraju][/LIGHT]", ex_link='film|country', page=1, mode='GatunekRok', iconImage='DefaultFolder.png', fanart=FANART)
            addDir(name="Seriale [LIGHT](wszystkie)[/LIGHT]", ex_link='https://filman.cc/seriale/', page=1, mode='ListSeriale', iconImage='DefaultTVShows.png')
            addDir(name=" [LIGHT] - wg wybranych [Kategorii][/LIGHT]", ex_link='serial|category', page=1, mode='GatunekRok', iconImage='DefaultGenre.png')
            # addDir(name=" Ostatnio dodane seriale", ex_link='https://filman.cc/seriale/|Ostatnio dodane seriale', page=1, mode='ListSeriale', iconImage='DefaultRecentlyAddedEpisodes.png')
            # addDir(name=" Popularne seriale", ex_link='https://filman.cc/seriale/|Popularne seriale', page=1, mode='ListSeriale', iconImage='DefaultFolder.png')
            addDir(name="Dla dzieci", ex_link='https://filman.cc/dla-dzieci-pl/', page=1, mode='ListMoviesKids', iconImage='DefaultAddonImages.png')
            # addDir(name="[COLOR magenta]Zaskocz mnie[/COLOR]", ex_link='https://filman.cc/zaskocz-mnie', page=0, mode='getMovie', iconImage='DefaultFolder.png')
            addLinkItem('Zaskocz mnie [LIGHT](losowy film)[/LIGHT]', 'https://filman.cc/zaskocz-mnie', 'getLinks', iconimage='DefaultAddon.png', fanart=None, IsPlayable=True, infoLabels={"title": "niespodzianka", "plot": "losowo wybrany film"})
            addLinkItem("[COLOR lightgrey]Jakość:[/COLOR] [B]"+qualityn+"[/B]", '', mode='filtr:quality', iconimage='DefaultAddonService.png')
            addLinkItem("[COLOR lightgrey]Wersje językowe:[/COLOR] [B]"+versionn+"[/B]", '', mode='filtr:version', iconimage='DefaultAddonService.png')
            addLinkItem("[COLOR lightgrey]Sortowanie filmów:[/COLOR] [B]"+sortn+"[/B]", '', mode='filtr:sort', iconimage='DefaultAddonService.png')
            addLinkItem("[COLOR lightgrey]Sortowanie seriali:[/COLOR] [B]"+sortn_s+"[/B]", '', mode='filtr:sort_s', iconimage='DefaultAddonService.png')
            addLinkItem('[I]-= Pozostałe Opcje =-[/I]', '', 'Opcje', iconimage='DefaultAddonProgram.png')

        # xbmcplugin.setContent(addon_handle, 'addons')  # na domyślnej skórce dziwne ikonki po prawej
        # xbmcplugin.setContent(addon_handle, 'files')
        xbmcplugin.endOfDirectory(addon_handle,True)

# xbmc.log("KONIEC pliku",1)
if __name__ == '__main__':
    router(sys.argv[2][1:])    
